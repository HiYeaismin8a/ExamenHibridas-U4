// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyBYxZ3VAhb6A3NkbFEp3cpSebiyNv_cNgY",
    authDomain: "examen-u4-b72cb.firebaseapp.com",
    projectId: "examen-u4-b72cb",
    storageBucket: "examen-u4-b72cb.appspot.com",
    messagingSenderId: "965940859602",
    appId: "1:965940859602:web:fbe891ea09f4737a4d930b",
    measurementId: "G-VG8DL3429B"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
