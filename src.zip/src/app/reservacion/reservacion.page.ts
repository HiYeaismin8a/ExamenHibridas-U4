import { Component, OnInit } from '@angular/core';

import { ActivatedRoute } from '@angular/router';
import { Reservacion } from 'src/app/interfaces/Reservacion';

@Component({
  selector: 'app-reservacion',
  templateUrl: './reservacion.page.html',
  styleUrls: ['./reservacion.page.scss'],
})
export class ReservacionPage implements OnInit {
  total = 0;

  reservacion: Reservacion = {
    costoTotal: 0,
    fecha: new Date().toISOString(),
    nombreCliente: '',
    telefonoCliente: '',
  };

  constructor(private activatedRoute: ActivatedRoute) {}

  ngOnInit() {
    console.log('reservacion');
    this.activatedRoute.params.subscribe((params) => {
      console.log(params['id'])
    });
  }

  calcular() {}
}
