import {
  AngularFirestore,
  AngularFirestoreCollection,
} from '@angular/fire/compat/firestore';

import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root',
})
export class ClientesService {
  coleccion: AngularFirestoreCollection;
  constructor(private afs: AngularFirestore) {
    this.coleccion = afs.collection('clientes');
  }

  getCliente(telefono: string) {
    return this.coleccion.ref.where('telefono', '==', telefono).get();
  }
}
