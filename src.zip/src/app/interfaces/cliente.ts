export interface Cliente {
  telefono:string;
  domicilio: string;
  nombre:string;
}
