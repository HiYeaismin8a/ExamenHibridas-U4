export interface Administrador {
  nombre: string;
  telefono: string;
  fecha: Date;
  costoTotal: number;
}
