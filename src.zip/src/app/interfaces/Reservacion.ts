export interface Reservacion {
  telefonoCliente: string;
  nombreCliente: string;
  fecha: string;
  costoTotal: number;
}

